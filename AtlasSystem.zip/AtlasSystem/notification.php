<?php
session_start();
$host = "localhost";
$username = "root";
$password = "";
$dbname = "atlas_db";

$conn = new mysqli($host, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch recent task activities to serve as system notifications
$activity_query = "SELECT t.title, t.priority, t.status, t.due_date, e.full_name 
                   FROM tasks t 
                   LEFT JOIN employees e ON t.assigned_to_employee_id = e.employee_id 
                   ORDER BY t.task_id DESC LIMIT 10";
$activity_result = $conn->query($activity_query);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <!-- Mobile responsiveness viewport tag -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <title>Atlas Cargo Systems - System Notifications</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

<div class="dashboard-layout" style="width: 100%;">
    <!-- Sidebar Navigation -->
    <?php include 'sidebar.php'; ?>

    <!-- Main Content Area -->
    <div class="main-area">
        <div class="top-bar">
            <span><strong>System Activity & Alerts</strong> - Recent task assignments and updates</span>
            <span>Role: Manager</span>
        </div>

        <div class="data-table-box" style="margin-top: 20px;">
            <h3>Recent Task Activities & Notifications Feed</h3>
            <table>
                <thead>
                    <tr>
                        <th>Activity Summary</th>
                        <th>Assigned Personnel</th>
                        <th>Priority</th>
                        <th>Current Status</th>
                        <th>Due Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($activity_result->num_rows > 0) { 
                        while($row = $activity_result->fetch_assoc()) { ?>
                    <tr>
                        <td>New task entry: <strong><?php echo htmlspecialchars($row['title']); ?></strong></td>
                        <td><?php echo htmlspecialchars($row['full_name'] ?? 'Unassigned'); ?></td>
                        <td><?php echo $row['priority']; ?></td>
                        <td><span style="color: #0056b3;"><?php echo $row['status']; ?></span></td>
                        <td><?php echo $row['due_date']; ?></td>
                    </tr>
                    <?php } 
                    } else { ?>
                    <tr>
                        <td colspan="5" style="text-align: center; color: #777;">No recent system notifications.</td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

</body>
</html>