<?php
session_start();
$host = "localhost";
$username = "root";
$password = "";
$dbname = "atlas_db";

$conn = new mysqli($host, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Generate CSRF token if one does not exist yet
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$error_message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $submitted_token = $_POST['csrf_token'] ?? '';

    if (!hash_equals($_SESSION['csrf_token'], $submitted_token)) {
        $error_message = "Invalid request token. Please refresh and try again.";
    } else {
        $email = trim($_POST['email']);
        $password_input = $_POST['password'];

        // Prepared statement to securely fetch user details
        $stmt = $conn->prepare("SELECT user_id, email, password_hash, role, account_status FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($row = $result->fetch_assoc()) {
            if ($row['account_status'] == 'Active') {
                if ($password_input === $row['password_hash'] || password_verify($password_input, $row['password_hash'])) {
                    // Rotate token after successful login
                    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));

                    $_SESSION['user_id'] = $row['user_id'];
                    $_SESSION['email'] = $row['email'];
                    $_SESSION['role'] = $row['role'];

                    // Role-based routing corrected to Manager Dashboard
                    if ($row['role'] == 'Admin') {
                        header("Location: manager_dashboard.php");
                    } elseif ($row['role'] == 'Manager') {
                        header("Location: manager_dashboard.php");
                    } else {
                        header("Location: employee_dashboard.php");
                    }
                    exit();
                } else {
                    $error_message = "Invalid email or password.";
                }
            } else {
                $error_message = "Your account has been deactivated.";
            }
        } else {
            $error_message = "Invalid email or password.";
        }
        $stmt->close();
    }
}
$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <!-- Mobile responsiveness viewport tag -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <title>Atlas Cargo Systems - Login</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
     <div class="auth-container">
    <!-- Logo at the top of pages without a sidebar -->
    <div class="auth-logo-wrapper">
        <img src="Assets/images.jpg" alt="Atlas Cargo Systems Limited" class="auth-logo">
    </div>

<div class="login-card">
    <h2>Atlas Cargo Systems</h2>
    <p class="subtitle">Employee Task & Performance Management</p>
    
    <?php if(!empty($error_message)) echo "<div class='error'>$error_message</div>"; ?>

    <form method="POST" action="">
        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8'); ?>">

        <label>Email Address</label>
        <input type="email" name="email" required placeholder="Enter your email address">

        <label>Password</label>
        <input type="password" name="password" required placeholder="Enter your password">

        <button type="submit">Login</button>
        <p style="text-align: center; margin-top: 15px; font-size: 14px;">
            Don't have an account? <a href="register.php" style="color: #003366; text-decoration: none; font-weight: bold;">Register here</a>
        </p>
    </form>
</div>

</body>
</html>