<?php
session_start();
$host = "localhost";
$username = "root";
$password = "";
$dbname = "atlas_db";

$conn = new mysqli($host, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch all employees and join with users table to get email and role
$employees_query = "SELECT e.employee_id, e.full_name, e.department, e.job_title, u.email, u.role, u.account_status 
                    FROM employees e 
                    JOIN users u ON e.user_id = u.user_id 
                    ORDER BY e.employee_id DESC";
$employees_result = $conn->query($employees_query);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <!-- Mobile responsiveness viewport tag -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Atlas Cargo Systems - Team Members</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

<div class="dashboard-layout" style="width: 100%;">
    <!-- Sidebar Navigation -->
   <?php include 'sidebar.php'; ?>

    <!-- Main Content Area -->
    <div class="main-area">
        <div class="top-bar">
            <span><strong>Team Directory</strong> - View and manage organizational personnel</span>
            <span>Role: Manager</span>
        </div>

        <div class="data-table-box" style="margin-top: 20px;">
            <h3>Registered Personnel & Workforce Directory</h3>
            <table>
                <thead>
                    <tr>
                        <th>#ID</th>
                        <th>Full Name</th>
                        <th>Department / Management Area</th>
                        <th>Job Title</th>
                        <th>Email Address</th>
                        <th>System Role</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($employees_result->num_rows > 0) { 
                        while($row = $employees_result->fetch_assoc()) { ?>
                    <tr>
                        <td><?php echo $row['employee_id']; ?></td>
                        <td><?php echo htmlspecialchars($row['full_name']); ?></td>
                        <td><?php echo htmlspecialchars($row['department']); ?></td>
                        <td><?php echo htmlspecialchars($row['job_title']); ?></td>
                        <td><?php echo htmlspecialchars($row['email']); ?></td>
                        <td><strong><?php echo $row['role']; ?></strong></td>
                        <td>
                            <span style="color: <?php echo ($row['account_status'] == 'Active') ? 'green' : 'red'; ?>;">
                                <?php echo $row['account_status']; ?>
                            </span>
                        </td>
                    </tr>
                    <?php } 
                    } else { ?>
                    <tr>
                        <td colspan="7" style="text-align: center; color: #777;">No team members registered in the system yet.</td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

</body>
</html>