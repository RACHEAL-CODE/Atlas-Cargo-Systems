<?php
session_start();
$host = "localhost";
$username = "root";
$password = "";
$dbname = "atlas_db";

$conn = new mysqli($host, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Ensure the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$employee_id = $_SESSION['user_id'];

// Fetch tasks specifically assigned to this logged-in employee to show relevant notifications
$sql = "SELECT title, status, due_date FROM tasks WHERE assigned_to_employee_id = ? ORDER BY task_id DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $employee_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <!-- Mobile responsiveness viewport tag -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <title>Atlas Cargo Systems - Employee Notifications</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

<div class="dashboard-layout" style="width: 100%;">
    <!-- Include your dedicated employee sidebar -->
    <?php include 'employee_sidebar.php'; ?>

    <!-- Main Content Area -->
    <div class="main-area">
        <div class="top-bar">
            <span><strong>Employee Notifications</strong> - Your Assigned Task Updates</span>
            <span>Role: Employee</span>
        </div>

        <div class="data-table-box" style="margin-top: 20px;">
            <h3>Task Notification Feed</h3>
            <table>
                <thead>
                    <tr>
                        <th>Task Title</th>
                        <th>Current Status</th>
                        <th>Due Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($result && $result->num_rows > 0) { 
                        while($row = $result->fetch_assoc()) { ?>
                    <tr>
                        <td>Task update: <strong><?php echo htmlspecialchars($row['title']); ?></strong></td>
                        <td><span style="padding: 3px 6px; background: #e9ecef; border-radius: 3px;"><?php echo htmlspecialchars($row['status']); ?></span></td>
                        <td><?php echo htmlspecialchars($row['due_date']); ?></td>
                    </tr>
                    <?php } 
                    } else { ?>
                    <tr>
                        <td colspan="3" style="text-align: center; color: #777;">No new notifications found.</td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
        
        <div style="margin-top: 20px;">
            <a href="employee_dashboard.php" style="color: #0056b3; text-decoration: none;">&larr; Back to Dashboard</a>
        </div>
    </div>
</div>

</body>
</html>