<?php
session_start();
$host = "localhost";
$username = "root";
$password = "";
$dbname = "atlas_db";

$conn = new mysqli($host, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch performance stats
$total_tasks = $conn->query("SELECT COUNT(*) as count FROM tasks")->fetch_assoc()['count'];
$completed_tasks = $conn->query("SELECT COUNT(*) as count FROM tasks WHERE status='Completed'")->fetch_assoc()['count'];
$pending_tasks = $conn->query("SELECT COUNT(*) as count FROM tasks WHERE status='Pending'")->fetch_assoc()['count'];
$in_progress = $conn->query("SELECT COUNT(*) as count FROM tasks WHERE status='In Progress'")->fetch_assoc()['count'];

// Calculate completion rate percentage
$completion_rate = ($total_tasks > 0) ? round(($completed_tasks / $total_tasks) * 100, 1) : 0;

// Fetch employee performance breakdown
$perf_query = "SELECT e.full_name, e.department, 
                COUNT(t.task_id) as total_assigned,
                SUM(CASE WHEN t.status = 'Completed' THEN 1 ELSE 0 END) as completed_count
               FROM employees e
               LEFT JOIN tasks t ON e.employee_id = t.assigned_to_employee_id
               GROUP BY e.employee_id";
$perf_result = $conn->query($perf_query);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <!-- Mobile responsiveness viewport tag -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <title>Atlas Cargo Systems - Performance Reports</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

<div class="dashboard-layout" style="width: 100%;">
    <!-- Sidebar Navigation -->
   <?php include 'sidebar.php'; ?>

    <!-- Main Content Area -->
    <div class="main-area">
        <div class="top-bar">
            <span><strong>Performance Reports</strong> - Workforce productivity analytics</span>
            <span>Role: Manager</span>
        </div>

    
        <!-- Summary Cards -->
        <div class="metric-grid" style="margin-top: 25px;">
            <div class="metric-card">
                <h3><?php echo $completion_rate; ?>%</h3>
                <p>Overall Completion Rate</p>
            </div>
            <div class="metric-card">
                <h3><?php echo $completed_tasks; ?> / <?php echo $total_tasks; ?></h3>
                <p>Completed vs Total Tasks</p>
            </div>
            <div class="metric-card">
                <h3><?php echo $pending_tasks + $in_progress; ?></h3>
                <p>Active / Pending Workload</p>
            </div>
        </div>

        <!-- Employee Productivity Table -->
        <div class="data-table-box" style="margin-top: 20px;">
            <h3>Staff Productivity & Task Allocation Breakdown</h3>
            <table>
                <thead>
                    <tr>
                        <th>Employee Name</th>
                        <th>Department</th>
                        <th>Total Tasks Assigned</th>
                        <th>Tasks Completed</th>
                        <th>Performance Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($perf_result->num_rows > 0) { 
                        while($row = $perf_result->fetch_assoc()) { 
                            $assigned = $row['total_assigned'];
                            $done = $row['completed_count'] ?? 0;
                            $rate = ($assigned > 0) ? round(($done / $assigned) * 100) : 0;
                    ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['full_name']); ?></td>
                        <td><?php echo htmlspecialchars($row['department']); ?></td>
                        <td><?php echo $assigned; ?></td>
                        <td><?php echo $done; ?></td>
                        <td><strong><?php echo $rate; ?>% Completed</strong></td>
                    </tr>
                    <?php } 
                    } else { ?>
                    <tr>
                        <td colspan="5" style="text-align: center; color: #777;">No performance records available.</td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

</body>
</html>