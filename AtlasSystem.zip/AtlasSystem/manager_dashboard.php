<?php
session_start();
$host = "localhost";
$username = "root";
$password = "";
$dbname = "atlas_db";

$conn = new mysqli($host, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch task statistics for the dashboard summary cards
$total_tasks = $conn->query("SELECT COUNT(*) as count FROM tasks")->fetch_assoc()['count'];
$in_progress = $conn->query("SELECT COUNT(*) as count FROM tasks WHERE status='In Progress'")->fetch_assoc()['count'];
$completed = $conn->query("SELECT COUNT(*) as count FROM tasks WHERE status='Completed'")->fetch_assoc()['count'];

// Fetch recent tasks for the manager's overview table
$tasks_result = $conn->query("SELECT t.task_id, t.title, e.full_name, t.priority, t.due_date, t.status FROM tasks t LEFT JOIN employees e ON t.assigned_to_employee_id = e.employee_id ORDER BY t.task_id DESC LIMIT 5");
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <!-- Mobile responsiveness viewport tag -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <title>Atlas Cargo Systems - Manager Dashboard</title>
    
    <link rel="stylesheet" href="styles.css">
</head>
<body>

<div class="dashboard-layout" style="width: 100%;">
    <!-- Sidebar Navigation -->
    <?php include 'sidebar.php'; ?>
    
    <!-- Main Content Area -->
    <div class="main-area">
        <div class="top-bar">
            <span><strong>Welcome, Manager</strong> - Manage your team and tasks.</span>
            <span>Role: Manager</span>
        </div>
    
        <!-- Summary Cards -->
        <div class="metric-grid" style="margin-top: 25px;">
            <div class="metric-card">
                <h3><?php echo $total_tasks; ?></h3>
                <p>Total Tasks</p>
            </div>
            <div class="metric-card">
                <h3><?php echo $in_progress; ?></h3>
                <p>In Progress</p>
            </div>
            <div class="metric-card">
                <h3><?php echo $completed; ?></h3>
                <p>Completed</p>
            </div>
        </div>

        <!-- Recent Tasks Overview Table -->
        <div class="data-table-box" style="margin-top: 25px;">
            <h3>Recent Tasks Overview</h3>
            <table>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Task Title</th>
                        <th>Assigned To</th>
                        <th>Priority</th>
                        <th>Due Date</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($tasks_result && $tasks_result->num_rows > 0) { 
                        while($row = $tasks_result->fetch_assoc()) { ?>
                    <tr>
                        <td><?php echo $row['task_id']; ?></td>
                        <td><?php echo htmlspecialchars($row['title']); ?></td>
                        <td><?php echo htmlspecialchars($row['full_name'] ?? 'Unassigned'); ?></td>
                        <td><?php echo htmlspecialchars($row['priority']); ?></td>
                        <td><?php echo htmlspecialchars($row['due_date']); ?></td>
                        <td><strong><?php echo htmlspecialchars($row['status']); ?></strong></td>
                    </tr>
                    <?php } 
                    } else { ?>
                    <tr>
                        <td colspan="6" style="text-align: center; color: #777;">No tasks found in the system.</td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

</body>
</html>