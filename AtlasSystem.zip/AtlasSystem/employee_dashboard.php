<?php
session_start();
$host = "localhost";
$username = "root";
$password = "";
$dbname = "atlas_db";

$conn = new mysqli($host, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Ensure employee is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Get the employee record linked to the logged-in user
$emp_query = "SELECT * FROM employees WHERE user_id = $user_id";
$emp_result = $conn->query($emp_query);
$employee = $emp_result->fetch_assoc();
$employee_id = $employee['employee_id'] ?? 0;

// Handle inline status updates from the tasks table
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $task_id = intval($_POST['task_id']);
    $new_status = $conn->real_escape_string($_POST['status']);
    
    $update_sql = "UPDATE tasks SET status = '$new_status' WHERE task_id = $task_id AND assigned_to_employee_id = $employee_id";
    $conn->query($update_sql);
    header("Location: employee_dashboard.php");
    exit();
}

// Fetch metrics for logged-in employee tasks
$my_tasks_count = $conn->query("SELECT COUNT(*) as count FROM tasks WHERE assigned_to_employee_id = $employee_id")->fetch_assoc()['count'];
$in_progress_count = $conn->query("SELECT COUNT(*) as count FROM tasks WHERE assigned_to_employee_id = $employee_id AND status='In Progress'")->fetch_assoc()['count'];
$completed_count = $conn->query("SELECT COUNT(*) as count FROM tasks WHERE assigned_to_employee_id = $employee_id AND status='Completed'")->fetch_assoc()['count'];

// Fetch unread notification count for badge display
$notif_count_query = $conn->query("SELECT COUNT(*) as count FROM notifications WHERE employee_id = $employee_id AND is_read = 0");
$unread_notifications = ($notif_count_query && $row_notif = $notif_count_query->fetch_assoc()) ? $row_notif['count'] : 0;

// Handle search and filter inputs
$search_keyword = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';
$status_filter = isset($_GET['status_filter']) ? $conn->real_escape_string($_GET['status_filter']) : '';

// Build base query
$query = "SELECT * FROM tasks WHERE assigned_to_employee_id = $employee_id";

if (!empty($search_keyword)) {
    $query .= " AND (title LIKE '%$search_keyword%' OR description LIKE '%$search_keyword%')";
}

if (!empty($status_filter)) {
    $query .= " AND status = '$status_filter'";
}

$query .= " ORDER BY due_date ASC";
$tasks_result = $conn->query($query);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <!-- Mobile responsiveness viewport tag -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Atlas Cargo Systems - Employee Dashboard</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        .action-btn { color: #d9534f; text-decoration: none; font-weight: bold; font-size: 13px; }
        .action-btn:hover { text-decoration: underline; }
        .top-action-bar { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
        .btn-primary { background-color: #003366; color: white; padding: 8px 15px; border-radius: 4px; text-decoration: none; font-size: 14px; }
        .btn-primary:hover { background-color: #002244; }
    </style>
</head>
<body>

<div class="dashboard-layout" style="width: 100%;">
    <!-- Sidebar Navigation -->
    <?php include 'employee_sidebar.php'; ?>
    
    <!-- Main Content Area -->
    <div class="main-area">
        <div class="top-bar">
            <span><strong>Welcome, <?php echo htmlspecialchars($employee['full_name'] ?? 'Employee'); ?></strong> - Here are your current tasks and updates</span>
            <span>Role: Employee</span>
        </div>

        <!-- Summary Cards -->
        <div class="metric-grid" style="margin-top: 25px;">
            <div class="metric-card">
                <h3><?php echo $my_tasks_count; ?></h3>
                <p>My Tasks</p>
            </div>
            <div class="metric-card">
                <h3><?php echo $in_progress_count; ?></h3>
                <p>In Progress</p>
            </div>
            <div class="metric-card">
                <h3><?php echo $completed_count; ?></h3>
                <p>Completed</p>
            </div>
        </div>

        <!-- Tasks Table & Search/Filter Section -->
        <div class="data-table-box" style="margin-top: 25px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px; flex-wrap: wrap; gap: 10px;">
                <h3>Assigned Tasks & Status Updates</h3>
                
                <!-- Search & Filter Form -->
                <form method="GET" style="display: flex; gap: 8px; align-items: center;">
                    <input type="text" name="search" placeholder="Search tasks..." value="<?php echo htmlspecialchars($search_keyword); ?>" style="padding: 6px 10px; border: 1px solid #ccc; border-radius: 4px; font-size: 14px;">
                    
                    <select name="status_filter" style="padding: 6px; border: 1px solid #ccc; border-radius: 4px; font-size: 14px;">
                        <option value="">All Statuses</option>
                        <option value="Pending" <?php if($status_filter=='Pending') echo 'selected'; ?>>Pending</option>
                        <option value="In Progress" <?php if($status_filter=='In Progress') echo 'selected'; ?>>In Progress</option>
                        <option value="Completed" <?php if($status_filter=='Completed') echo 'selected'; ?>>Completed</option>
                    </select>
                    
                    <button type="submit" style="padding: 6px 12px; background: #0056b3; color: white; border: none; border-radius: 4px; cursor: pointer;">Filter</button>
                    
                    <?php if(!empty($search_keyword) || !empty($status_filter)): ?>
                        <a href="employee_dashboard.php" style="padding: 6px 10px; background: #6c757d; color: white; text-decoration: none; border-radius: 4px; font-size: 14px;">Reset</a>
                    <?php endif; ?>
                </form>
            </div>

            <table>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Task Title</th>
                        <th>Description</th>
                        <th>Priority</th>
                        <th>Due Date</th>
                        <th>Current Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($tasks_result && $tasks_result->num_rows > 0) { 
                        while($row = $tasks_result->fetch_assoc()) { ?>
                    <tr>
                        <td><?php echo $row['task_id']; ?></td>
                        <td><strong><?php echo htmlspecialchars($row['title']); ?></strong></td>
                        <td><?php echo htmlspecialchars($row['description']); ?></td>
                        <td><?php echo htmlspecialchars($row['priority']); ?></td>
                        <td><?php echo htmlspecialchars($row['due_date']); ?></td>
                        <td>
                            <span style="padding: 4px 8px; border-radius: 4px; background: #e9ecef;">
                                <?php echo htmlspecialchars($row['status']); ?>
                            </span>
                        </td>
                        <td>
                            <form method="POST" style="display: flex; gap: 5px;">
                                <input type="hidden" name="task_id" value="<?php echo $row['task_id']; ?>">
                                <select name="status" style="padding: 4px; font-size: 12px;">
                                    <option value="Pending" <?php if($row['status']=='Pending') echo 'selected'; ?>>Pending</option>
                                    <option value="In Progress" <?php if($row['status']=='In Progress') echo 'selected'; ?>>In Progress</option>
                                    <option value="Completed" <?php if($row['status']=='Completed') echo 'selected'; ?>>Completed</option>
                                </select>
                                <button type="submit" name="update_status" style="padding: 4px 8px; background: #0056b3; color: white; border: none; border-radius: 3px; cursor: pointer;">Update</button>
                            </form>
                        </td>
                    </tr>
                    <?php } 
                    } else { ?>
                    <tr>
                        <td colspan="7" style="text-align: center; color: #777;">No tasks currently match your search criteria.</td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

</body>
</html>