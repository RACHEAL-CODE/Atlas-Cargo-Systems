<?php
// Ensure database connection and employee ID exist for the badge count
if (!isset($conn)) {
    $conn = new mysqli("localhost", "root", "", "atlas_db");
}
$current_emp_id = isset($_SESSION['employee_id']) ? intval($_SESSION['employee_id']) : 1;

// Count pending tasks assigned to this specific employee
$badge_stmt = $conn->prepare("SELECT COUNT(*) as total FROM tasks WHERE assigned_to_employee_id = ? AND status = 'Pending'");
$badge_stmt->bind_param("i", $current_emp_id);
$badge_stmt->execute();
$badge_res = $badge_stmt->get_result()->fetch_assoc();
$unread_notifications = $badge_res['total'] ?? 0;
$badge_stmt->close();
?>

<div class="sidebar">
    <div class="sidebar-brand">
        <img src="Assets/images.jpg" alt="Atlas Cargo Systems Limited" class="sidebar-logo">
    </div>
    <div class="sidebar-header">Atlas Cargo Systems</div>
    
    <a href="employee_dashboard.php" <?php if(basename($_SERVER['PHP_SELF']) == 'employee_dashboard.php') echo 'class="active"'; ?>>Dashboard</a>
    
    <a href="employee_dashboard.php" <?php if(basename($_SERVER['PHP_SELF']) == 'employee_dashboard.php' && isset($_GET['view'])) echo 'class="active"'; ?>>My Tasks</a>
    
    <a href="employee_notification.php" <?php if(basename($_SERVER['PHP_SELF']) == 'employee_notification.php') echo 'class="active"'; ?>>
        Notifications 
        <?php if (isset($unread_notifications) && $unread_notifications > 0): ?>
            <span style="background: #dc3546; color: white; padding: 2px 6px; border-radius: 50px; font-size: 11px; font-weight: bold; margin-left: 5px;">
                <?php echo $unread_notifications; ?>
            </span>
        <?php endif; ?>
    </a>
    
    <a href="login.php" style="margin-top: auto; color: #d9534f;">Logout</a>
</div>