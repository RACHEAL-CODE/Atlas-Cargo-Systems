<?php
session_start();
$host = "localhost";
$username = "root";
$password = "";
$dbname = "atlas_db";

$conn = new mysqli($host, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Generate CSRF token if one does not exist yet
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$message = "";
$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $submitted_token = $_POST['csrf_token'] ?? '';

    if (!hash_equals($_SESSION['csrf_token'], $submitted_token)) {
        $error = "Invalid request token. Please refresh and try again.";
    } else {
        $email = trim($_POST['email']);
        $password_input = $_POST['password'];
        $full_name = trim($_POST['full_name']);
        $department = $_POST['department'];
        $job_title = $_POST['job_title'];
        $role = $_POST['role'];

        // Checks if email already exists
        $check_stmt = $conn->prepare("SELECT user_id FROM users WHERE email = ?");
        $check_stmt->bind_param("s", $email);
        $check_stmt->execute();
        $check_stmt->store_result();

        if ($check_stmt->num_rows > 0) {
            $error = "Email address is already registered.";
        } else {
            // Hash password before storing in database
            $hashed_password = password_hash($password_input, PASSWORD_DEFAULT);

            // Insert into users table
            $stmt = $conn->prepare("INSERT INTO users (email, password_hash, role, account_status) VALUES (?, ?, ?, 'Active')");
            $stmt->bind_param("sss", $email, $hashed_password, $role);

            if ($stmt->execute()) {
                $user_id = $stmt->insert_id;

                // Insert corresponding employee details
                $emp_stmt = $conn->prepare("INSERT INTO employees (user_id, full_name, department, job_title) VALUES (?, ?, ?, ?)");
                $emp_stmt->bind_param("isss", $user_id, $full_name, $department, $job_title);
                $emp_stmt->execute();
                $emp_stmt->close();

                // Rotate token after successful registration
                $_SESSION['csrf_token'] = bin2hex(random_bytes(32));

                $message = "Registration successful! You can now <a href='login.php'>log in here</a>.";
            } else {
                $error = "Error during registration: " . $conn->error;
            }
            $stmt->close();
        }
        $check_stmt->close();
    }
}
$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <!-- Mobile responsiveness viewport tag -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <title>Atlas Cargo Systems - Register</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="auth-container">
        <!-- Logo at the top of pages without a sidebar -->
        <div class="auth-logo-wrapper">
            <img src="Assets/images.jpg" alt="Atlas Cargo Systems Limited" class="auth-logo">
        </div>

        <div class="login-card" style="max-width: 450px;">
            <h2>Atlas Cargo Systems</h2>
            <p class="subtitle">User Registration Portal</p>
            
            <?php if(!empty($error)) echo "<div class='error'>$error</div>"; ?>
            <?php if(!empty($message)) echo "<div class='success-msg' style='background-color:#d4edda; color:#155724; padding:10px; border-radius:4px; margin-bottom:15px; text-align:center;'>$message</div>"; ?>

            <form method="POST" action="">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8'); ?>">

                <label>Full Name</label>
                <input type="text" name="full_name" required placeholder="e.g., Mukisa Moses">

                <label>Email Address</label>
                <input type="email" name="email" required placeholder="e.g., moses@atlas.com">

                <label>Password</label>
                <input type="password" name="password" required placeholder="Enter password">

                <label>Department / Management Area</label>
                <select id="department" name="department" required onchange="updateJobTitles()" style="width: 100%; padding: 10px; margin-top: 5px; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box;">
                    <option value="">-- Select Department --</option>
                    <option value="Executive Management">Executive Management</option>
                    <option value="Commercial Department">Commercial Department</option>
                    <option value="Business Development">Business Development</option>
                    <option value="Finance Department">Finance Department</option>
                    <option value="Human Resources">Human Resources</option>
                    <option value="Operations Department">Operations Department</option>
                </select>

                <label>Job Title</label>
                <select id="job_title" name="job_title" required style="width: 100%; padding: 10px; margin-top: 5px; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box;">
                    <option value="">-- First Select a Department --</option>
                </select>

                <label>System Role</label>
                <select name="role" required style="width: 100%; padding: 10px; margin-top: 5px; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box;">
                    <option value="Employee">Employee</option>
                    <option value="Manager">Manager</option>
                    <option value="Admin">Admin</option>
                </select>

                <button type="submit">Register Account</button>
            </form>

            <p style="text-align: center; margin-top: 15px; font-size: 14px;">
                Already have an account? <a href="login.php" style="color: #003366; text-decoration: none; font-weight: bold;">Login here</a>
            </p>
        </div>
    </div>

<!-- JavaScript for Dynamic Job Titles -->
<script>
const jobTitlesByDepartment = {
    "Executive Management": [
        "Managing Director",
        "General Manager",
        "Executive Assistant",
        "Corporate Strategy Officer"
    ],
    "Commercial Department": [
        "Commercial Manager",
        "Key Account Manager",
        "Cargo Sales Executive",
        "Customer Relations Officer",
        "Pricing & Tariffs Specialist"
    ],
    "Business Development": [
        "Business Development Manager",
        "Route Expansion Specialist",
        "Market Research Analyst",
        "Partnership Coordinator"
    ],
    "Finance Department": [
        "Finance Manager",
        "Senior Accountant",
        "Accounts Payable/Receivable Officer",
        "Financial Analyst",
        "Payroll Specialist"
    ],
    "Human Resources": [
        "Human Resource Manager",
        "HR Officer",
        "Talent Acquisition Specialist",
        "Employee Welfare Coordinator"
    ],
    "Operations Department": [
        "Operations Manager",
        "Freight Forwarding Coordinator",
        "Warehouse Supervisor",
        "Fleet & Dispatch Officer",
        "Supply Chain Analyst"
    ]
};

function updateJobTitles() {
    const departmentSelect = document.getElementById("department");
    const jobTitleSelect = document.getElementById("job_title");
    const selectedDept = departmentSelect.value;

    // Clear previous options
    jobTitleSelect.innerHTML = '<option value="">-- Select Job Title --</option>';

    if (selectedDept && jobTitlesByDepartment[selectedDept]) {
        jobTitlesByDepartment[selectedDept].forEach(function(title) {
            const option = document.createElement("option");
            option.value = title;
            option.textContent = title;
            jobTitleSelect.appendChild(option);
        });
    } else {
        jobTitleSelect.innerHTML = '<option value="">-- First Select a Department --</option>';
    }
}
</script>

</body>
</html>