<?php
// Ensure database connection exists for the badge count
if (!isset($conn)) {
    $conn = new mysqli("localhost", "root", "", "atlas_db");
}

// Count tasks that are not completed (Pending or In Progress)
$badge_query = $conn->query("SELECT COUNT(*) as total FROM tasks WHERE status != 'Completed'");
$badge_row = $badge_query ? $badge_query->fetch_assoc() : ['total' => 0];
$notification_count = $badge_row['total'];
?>

<div class="sidebar">
    <div class="sidebar-brand">
        <img src="Assets/images.jpg" alt="Atlas Cargo Systems Limited" class="sidebar-logo">
    </div>


    <div class="sidebar-header">Atlas Cargo Systems</div>
    <a href="manager_dashboard.php">Dashboard</a>
    <a href="assign_task.php">Create Task</a>
    <a href="manage_tasks.php">Manage Tasks</a>
    <a href="team_members.php">Team Members</a>
    <a href="reports.php">Reports</a>
    
    <!-- Notifications Link with Dynamic Badge -->
    <a href="notification.php" style="display: flex; justify-content: space-between; align-items: center;">
        <span>Notifications</span>
        <?php if ($notification_count > 0): ?>
            <span style="background-color: #dc3545; color: white; padding: 2px 6px; font-size: 11px; font-weight: bold; border-radius: 50px;">
                <?php echo $notification_count; ?>
            </span>
        <?php endif; ?>
    </a>
    
    <a href="login.php" style="margin-top: auto; color: #d9534f;">Logout</a>
</div>