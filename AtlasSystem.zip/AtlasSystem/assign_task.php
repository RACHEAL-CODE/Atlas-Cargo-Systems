<?php
session_start();

// Database configuration
$host = "localhost";
$username = "root";
$password = "";
$dbname = "atlas_db";

$conn = new mysqli($host, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$message = "";
$error = "";

// Handle task submission from the manager form
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    // 1. Get the logged-in manager's user ID from session (stops assigned_by_user_id from being NULL)
    $assigned_by_user_id = isset($_SESSION['user_id']) ? intval($_SESSION['user_id']) : 1; 

    // 2. Capture form fields securely
    $title       = $conn->real_escape_string($_POST['title']);
    $description = $conn->real_escape_string($_POST['description']);
    $employee_id = intval($_POST['assigned_to_employee_id']);
    $priority    = $conn->real_escape_string($_POST['priority']);
    $due_date    = $conn->real_escape_string($_POST['due_date']);

    // 3. Include assigned_by_user_id in the INSERT query
    $sql = "INSERT INTO tasks (assigned_by_user_id, title, description, assigned_to_employee_id, priority, due_date, status) 
            VALUES ('$assigned_by_user_id', '$title', '$description', '$employee_id', '$priority', '$due_date', 'Pending')";

    if ($conn->query($sql) === TRUE) {
        // Automatically jump back to the dashboard upon success
        header("Location: manager_dashboard.php");
        exit();
    } else {
        $error = "Error: " . $conn->error;
    }
}
$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <!-- Mobile responsiveness viewport tag -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <title>Atlas Cargo Systems - Assign Task</title>
    <!-- Linked separate stylesheet -->
    <link rel="stylesheet" href="styles.css">
</head>
<body>

<div class="dashboard-container">
    <h2>Assign New Task</h2>
    <p class="subtitle">Atlas Cargo Systems Ltd - Management Module</p>

    <?php 
    if(!empty($message)) echo "<div class='success-msg'>$message</div>"; 
    if(!empty($error)) echo "<div class='error-msg' style='color: red; margin-bottom: 15px;'>$error</div>"; 
    ?>

    <form method="POST" action="">
        <label>Task Title</label>
        <input type="text" name="title" required placeholder="e.g., Monthly Logistics Audit">

        <label>Description</label>
        <textarea name="description" rows="4" required placeholder="Describe task expectations..."></textarea>

        <label>Priority Level</label>
        <select name="priority">
            <option value="Low">Low</option>
            <option value="Medium">Medium</option>
            <option value="High">High</option>
        </select>

        <label>Due Date</label>
        <input type="date" name="due_date" required>

        <label>Assign to Employee</label>
        <select name="assigned_to_employee_id" required style="width: 100%; padding: 8px; margin-bottom: 15px;">
            <option value="">-- Select Employee --</option>
            <?php
            // Re-open connection or query employees if connection was closed earlier
            $conn_temp = new mysqli("localhost", "root", "", "atlas_db");
            $emp_result = $conn_temp->query("SELECT employee_id, full_name, department FROM employees");
            while($emp = $emp_result->fetch_assoc()) {
                echo "<option value='" . $emp['employee_id'] . "'>" . htmlspecialchars($emp['full_name']) . " (" . htmlspecialchars($emp['department']) . ")</option>";
            }
            $conn_temp->close();
            ?>
        </select>
        

        <button type="submit">Publish & Assign Task</button>
        <div style="margin-top: 15px;">
            <a href="manager_dashboard.php" style="color: #6c757d; text-decoration: none;">&larr; Back to Dashboard</a>
        </div>
    </form>
    
    <p style="text-align: center; margin-top: 20px;">
        <a href="login.php" style="color: #003366; text-decoration: none; font-size: 14px;">Logout / Back to Login</a>
    </p>
</div>

</body>
</html>