<?php
session_start();

$host = "localhost";
$username = "root";
$password = "";
$dbname = "atlas_db";

$conn = new mysqli($host, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$message = "";

// Dynamically get the logged-in employee's ID from session (with fallback to 1 for testing)
$employee_id = isset($_SESSION['employee_id']) ? intval($_SESSION['employee_id']) : 1; 

// Handle form submission to update task status and progress notes
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $task_id       = intval($_POST['task_id']);
    $new_status    = $conn->real_escape_string($_POST['status']);
    $progress_note = $conn->real_escape_string($_POST['progress_note']);

    // Update the task status (and optionally a progress note column if it exists in your tasks table)
    $stmt = $conn->prepare("UPDATE tasks SET status = ?, description = CONCAT(description, '\n\n[Progress Note]: ', ?) WHERE task_id = ? AND assigned_to_employee_id = ?");
    $stmt->bind_param("ssii", $new_status, $progress_note, $task_id, $employee_id);

    if ($stmt->execute()) {
        $message = "Task status successfully updated to '$new_status'!";
    } else {
        $message = "Error updating task: " . $conn->error;
    }
    $stmt->close();
}

// Fetch tasks assigned to this specific employee so they can choose which one to update
$tasks_result = $conn->query("SELECT task_id, title, status FROM tasks WHERE assigned_to_employee_id = $employee_id");
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <!-- Mobile responsiveness viewport tag -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <title>Atlas Cargo Systems - Update Task Status</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

<div class="dashboard-layout" style="width: 100%;">
    <!-- Sidebar Navigation -->
    <?php include 'sidebar.php'; ?>
    
    <!-- Main Content Area -->
    <div class="main-area">
        <div class="top-bar">
            <span><strong>Update Task Progress</strong> Submit completion updates or change task status</span>
            <span>Role: Employee</span>
        </div>

        <div class="dashboard-container" style="margin: 20px auto; max-width: 700px;">
            <h3>Select a Task to Update</h3>
            
            <?php if(!empty($message)) echo "<div class='success-msg' style='padding: 10px; background: #d4edda; color: #155724; margin-bottom: 15px; border-radius: 4px;'>$message</div>"; ?>

            <form method="POST" action="">
                <label>Select Task</label>
                <select name="task_id" required style="width: 100%; padding: 8px; margin-bottom: 15px;">
                    <option value="">-- Choose Assigned Task --</option>
                    <?php while($t = $tasks_result->fetch_assoc()) { ?>
                        <option value="<?php echo $t['task_id']; ?>">
                            <?php echo "ID: " . $t['task_id'] . " - " . htmlspecialchars($t['title']) . " (Current: " . $t['status'] . ")"; ?>
                        </option>
                    <?php } ?>
                </select>

                <label>New Status</label>
                <select name="status" required style="width: 100%; padding: 8px; margin-bottom: 15px;">
                    <option value="Pending">Pending</option>
                    <option value="In Progress">In Progress</option>
                    <option value="Completed">Completed</option>
                </select>

                <label>Progress Notes / Completion Report</label>
                <textarea name="progress_note" rows="4" placeholder="Provide details about your progress or completion results..." style="width: 100%; padding: 8px; margin-bottom: 15px;"></textarea>

                <button type="submit" style="padding: 10px 20px; background: #003366; color: white; border: none; cursor: pointer; border-radius: 4px;">Submit Status Update</button>
            </form>
        </div>
    </div>
</div>

</body>
</html>