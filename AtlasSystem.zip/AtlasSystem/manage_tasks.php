<?php
session_start();
$host = "localhost";
$username = "root";
$password = "";
$dbname = "atlas_db";

$conn = new mysqli($host, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$message = "";

// Handle task deletion if requested by manager
if (isset($_GET['delete_id'])) {
    $delete_id = intval($_GET['delete_id']);
    $del_stmt = $conn->prepare("DELETE FROM tasks WHERE task_id = ?");
    $del_stmt->bind_param("i", $delete_id);
    if ($del_stmt->execute()) {
        $message = "Task successfully deleted.";
    } else {
        $message = "Error deleting task: " . $conn->error;
    }
    $del_stmt->close();
}

// Fetch all tasks with assigned employee names
$tasks_result = $conn->query("SELECT t.task_id, t.title, e.full_name, t.priority, t.due_date, t.status FROM tasks t LEFT JOIN employees e ON t.assigned_to_employee_id = e.employee_id ORDER BY t.task_id DESC");
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <!-- Mobile responsiveness viewport tag -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Atlas Cargo Systems - Manage Tasks</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        .action-btn { color: #d9534f; text-decoration: none; font-weight: bold; font-size: 13px; }
        .action-btn:hover { text-decoration: underline; }
        .top-action-bar { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
        .btn-primary { background-color: #003366; color: white; padding: 8px 15px; border-radius: 4px; text-decoration: none; font-size: 14px; }
        .btn-primary:hover { background-color: #002244; }
    </style>
</head>
<body>

<div class="dashboard-layout" style="width: 100%;">
    <!-- Sidebar Navigation -->
    <?php include 'sidebar.php'; ?>
    
    <!-- Main Content Area -->
    <div class="main-area">
        <div class="top-bar">
            <span><strong>Task Management Module</strong> - Track and oversee organizational task allocations.</span>
            <span>Role: Manager</span>
        </div>

        <div class="data-table-box" style="margin-top: 20px;">
            <div class="top-action-bar">
                <h3>Manage Tasks Directory</h3>
                <a href="assign_task.php" class="btn-primary">+ Add Task</a>
            </div>

            <?php if(!empty($message)) echo "<div class='success-msg' style='background-color:#e2f0d9; color:#385723; padding: 10px; margin-bottom: 15px; border-radius: 4px;'>$message</div>"; ?>

            <table>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Task Title</th>
                        <th>Assigned To</th>
                        <th>Priority</th>
                        <th>Due Date</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($tasks_result && $tasks_result->num_rows > 0) { 
                        while($row = $tasks_result->fetch_assoc()) { ?>
                    <tr>
                        <td><?php echo $row['task_id']; ?></td>
                        <td><?php echo htmlspecialchars($row['title']); ?></td>
                        <td><?php echo htmlspecialchars($row['full_name'] ?? 'Unassigned'); ?></td>
                        <td><?php echo htmlspecialchars($row['priority']); ?></td>
                        <td><?php echo htmlspecialchars($row['due_date']); ?></td>
                        <td><strong><?php echo htmlspecialchars($row['status']); ?></strong></td>
                        <td>
                            <a href="manage_tasks.php?delete_id=<?php echo $row['task_id']; ?>" class="action-btn" onclick="return confirm('Are you sure you want to delete this task?');">Delete</a>
                        </td>
                    </tr>
                    <?php } 
                    } else { ?>
                    <tr>
                        <td colspan="7" style="text-align: center; color: #777;">No tasks found in the database.</td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

</body>
</html>